// Generated from Lenguajex.g4 by ANTLR 4.13.1
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link LenguajexParser}.
 */
public interface LenguajexListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link LenguajexParser#program}.
	 * @param ctx the parse tree
	 */
	void enterProgram(LenguajexParser.ProgramContext ctx);
	/**
	 * Exit a parse tree produced by {@link LenguajexParser#program}.
	 * @param ctx the parse tree
	 */
	void exitProgram(LenguajexParser.ProgramContext ctx);
	/**
	 * Enter a parse tree produced by {@link LenguajexParser#functionDefinition}.
	 * @param ctx the parse tree
	 */
	void enterFunctionDefinition(LenguajexParser.FunctionDefinitionContext ctx);
	/**
	 * Exit a parse tree produced by {@link LenguajexParser#functionDefinition}.
	 * @param ctx the parse tree
	 */
	void exitFunctionDefinition(LenguajexParser.FunctionDefinitionContext ctx);
	/**
	 * Enter a parse tree produced by {@link LenguajexParser#mainFunction}.
	 * @param ctx the parse tree
	 */
	void enterMainFunction(LenguajexParser.MainFunctionContext ctx);
	/**
	 * Exit a parse tree produced by {@link LenguajexParser#mainFunction}.
	 * @param ctx the parse tree
	 */
	void exitMainFunction(LenguajexParser.MainFunctionContext ctx);
	/**
	 * Enter a parse tree produced by {@link LenguajexParser#parameterList}.
	 * @param ctx the parse tree
	 */
	void enterParameterList(LenguajexParser.ParameterListContext ctx);
	/**
	 * Exit a parse tree produced by {@link LenguajexParser#parameterList}.
	 * @param ctx the parse tree
	 */
	void exitParameterList(LenguajexParser.ParameterListContext ctx);
	/**
	 * Enter a parse tree produced by {@link LenguajexParser#parameter}.
	 * @param ctx the parse tree
	 */
	void enterParameter(LenguajexParser.ParameterContext ctx);
	/**
	 * Exit a parse tree produced by {@link LenguajexParser#parameter}.
	 * @param ctx the parse tree
	 */
	void exitParameter(LenguajexParser.ParameterContext ctx);
	/**
	 * Enter a parse tree produced by {@link LenguajexParser#type}.
	 * @param ctx the parse tree
	 */
	void enterType(LenguajexParser.TypeContext ctx);
	/**
	 * Exit a parse tree produced by {@link LenguajexParser#type}.
	 * @param ctx the parse tree
	 */
	void exitType(LenguajexParser.TypeContext ctx);
	/**
	 * Enter a parse tree produced by {@link LenguajexParser#block}.
	 * @param ctx the parse tree
	 */
	void enterBlock(LenguajexParser.BlockContext ctx);
	/**
	 * Exit a parse tree produced by {@link LenguajexParser#block}.
	 * @param ctx the parse tree
	 */
	void exitBlock(LenguajexParser.BlockContext ctx);
	/**
	 * Enter a parse tree produced by {@link LenguajexParser#statement}.
	 * @param ctx the parse tree
	 */
	void enterStatement(LenguajexParser.StatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link LenguajexParser#statement}.
	 * @param ctx the parse tree
	 */
	void exitStatement(LenguajexParser.StatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link LenguajexParser#variableDeclaration}.
	 * @param ctx the parse tree
	 */
	void enterVariableDeclaration(LenguajexParser.VariableDeclarationContext ctx);
	/**
	 * Exit a parse tree produced by {@link LenguajexParser#variableDeclaration}.
	 * @param ctx the parse tree
	 */
	void exitVariableDeclaration(LenguajexParser.VariableDeclarationContext ctx);
	/**
	 * Enter a parse tree produced by {@link LenguajexParser#assignment}.
	 * @param ctx the parse tree
	 */
	void enterAssignment(LenguajexParser.AssignmentContext ctx);
	/**
	 * Exit a parse tree produced by {@link LenguajexParser#assignment}.
	 * @param ctx the parse tree
	 */
	void exitAssignment(LenguajexParser.AssignmentContext ctx);
	/**
	 * Enter a parse tree produced by {@link LenguajexParser#incrementStatement}.
	 * @param ctx the parse tree
	 */
	void enterIncrementStatement(LenguajexParser.IncrementStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link LenguajexParser#incrementStatement}.
	 * @param ctx the parse tree
	 */
	void exitIncrementStatement(LenguajexParser.IncrementStatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link LenguajexParser#decrementStatement}.
	 * @param ctx the parse tree
	 */
	void enterDecrementStatement(LenguajexParser.DecrementStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link LenguajexParser#decrementStatement}.
	 * @param ctx the parse tree
	 */
	void exitDecrementStatement(LenguajexParser.DecrementStatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link LenguajexParser#whileLoop}.
	 * @param ctx the parse tree
	 */
	void enterWhileLoop(LenguajexParser.WhileLoopContext ctx);
	/**
	 * Exit a parse tree produced by {@link LenguajexParser#whileLoop}.
	 * @param ctx the parse tree
	 */
	void exitWhileLoop(LenguajexParser.WhileLoopContext ctx);
	/**
	 * Enter a parse tree produced by {@link LenguajexParser#ifStatement}.
	 * @param ctx the parse tree
	 */
	void enterIfStatement(LenguajexParser.IfStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link LenguajexParser#ifStatement}.
	 * @param ctx the parse tree
	 */
	void exitIfStatement(LenguajexParser.IfStatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link LenguajexParser#elseBlock}.
	 * @param ctx the parse tree
	 */
	void enterElseBlock(LenguajexParser.ElseBlockContext ctx);
	/**
	 * Exit a parse tree produced by {@link LenguajexParser#elseBlock}.
	 * @param ctx the parse tree
	 */
	void exitElseBlock(LenguajexParser.ElseBlockContext ctx);
	/**
	 * Enter a parse tree produced by {@link LenguajexParser#functionCall}.
	 * @param ctx the parse tree
	 */
	void enterFunctionCall(LenguajexParser.FunctionCallContext ctx);
	/**
	 * Exit a parse tree produced by {@link LenguajexParser#functionCall}.
	 * @param ctx the parse tree
	 */
	void exitFunctionCall(LenguajexParser.FunctionCallContext ctx);
	/**
	 * Enter a parse tree produced by {@link LenguajexParser#returnStatement}.
	 * @param ctx the parse tree
	 */
	void enterReturnStatement(LenguajexParser.ReturnStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link LenguajexParser#returnStatement}.
	 * @param ctx the parse tree
	 */
	void exitReturnStatement(LenguajexParser.ReturnStatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link LenguajexParser#showStatement}.
	 * @param ctx the parse tree
	 */
	void enterShowStatement(LenguajexParser.ShowStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link LenguajexParser#showStatement}.
	 * @param ctx the parse tree
	 */
	void exitShowStatement(LenguajexParser.ShowStatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link LenguajexParser#exprList}.
	 * @param ctx the parse tree
	 */
	void enterExprList(LenguajexParser.ExprListContext ctx);
	/**
	 * Exit a parse tree produced by {@link LenguajexParser#exprList}.
	 * @param ctx the parse tree
	 */
	void exitExprList(LenguajexParser.ExprListContext ctx);
	/**
	 * Enter a parse tree produced by {@link LenguajexParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterExpr(LenguajexParser.ExprContext ctx);
	/**
	 * Exit a parse tree produced by {@link LenguajexParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitExpr(LenguajexParser.ExprContext ctx);
	/**
	 * Enter a parse tree produced by {@link LenguajexParser#arrayLiteral}.
	 * @param ctx the parse tree
	 */
	void enterArrayLiteral(LenguajexParser.ArrayLiteralContext ctx);
	/**
	 * Exit a parse tree produced by {@link LenguajexParser#arrayLiteral}.
	 * @param ctx the parse tree
	 */
	void exitArrayLiteral(LenguajexParser.ArrayLiteralContext ctx);
}