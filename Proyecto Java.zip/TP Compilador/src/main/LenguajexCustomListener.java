import org.antlr.v4.runtime.ParserRuleContext;
import org.antlr.v4.runtime.tree.ErrorNode;
import org.antlr.v4.runtime.tree.TerminalNode;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class LenguajexCustomListener extends LenguajexBaseListener {

    private static StringBuilder code = new StringBuilder();
    private Map<String, String> symbolTable = new HashMap<>(); // Tabla de símbolos para rastrear variables y sus tipos
    private Set<String> undeclaredVariables = new HashSet<>(); // Set para rastrear variables no declaradas
    private Set<String> definedFunctions = new HashSet<>(); // Set para rastrear funciones definidas
    private boolean hasSemanticError = false; // Variable para rastrear errores semánticos

    @Override
    public void enterProgram(LenguajexParser.ProgramContext ctx) {
        code.setLength(0); // Reinicia el generador de código para un nuevo programa
        symbolTable.clear(); // Limpia la tabla de símbolos
        undeclaredVariables.clear(); // Limpia el conjunto de variables no declaradas
        definedFunctions.clear(); // Limpia el conjunto de funciones definidas
        hasSemanticError = false; // Reinicia el indicador de error semántico
    }

    @Override
    public void exitProgram(LenguajexParser.ProgramContext ctx) {
        //  Reporta cualquier variable no declarada
        for (String var : undeclaredVariables) {
            System.err.println("\tError Semántico: La variable '" + var + "' no fue declarada.");
            hasSemanticError = true; // Set semantic error flag
        }
        // Llama al método countDown() en el CountDownLatch para indicar que el listener ha terminado
        Main.latch.countDown();
    }

    @Override
    public void enterFunctionDefinition(LenguajexParser.FunctionDefinitionContext ctx) {
        String functionName = ctx.ID().getText();
        definedFunctions.add(functionName); // Agrega la función a la lista de funciones definidas
        code.append("function ").append(functionName).append("(");
        if (ctx.parameterList() != null) {
            code.append(formatParameters(ctx.parameterList()));
        }
        code.append(") {\n");
    }

    @Override
    public void exitFunctionDefinition(LenguajexParser.FunctionDefinitionContext ctx) {
        code.append("}\n");
    }

    @Override
    public void enterMainFunction(LenguajexParser.MainFunctionContext ctx) {
        code.append("function main() {\n");
    }

    @Override
    public void exitMainFunction(LenguajexParser.MainFunctionContext ctx) {
        code.append("}\nmain();\n");
    }

    @Override
    public void enterVariableDeclaration(LenguajexParser.VariableDeclarationContext ctx) {
        String varName = ctx.ID().getText();
        symbolTable.put(varName, ctx.type().getText()); // Agrego a la tabla de símbolos que uso para rastrear variables
        code.append("let ").append(varName);
        if (ctx.expr() != null) {
            code.append(" = ").append(ctx.expr().getText());
        }
        code.append(";\n");
    }

    @Override
    public void enterAssignment(LenguajexParser.AssignmentContext ctx) {
        String varName = ctx.ID().getText();
        if (!symbolTable.containsKey(varName)) {
            undeclaredVariables.add(varName);
        }
        code.append(varName).append(" = ").append(ctx.expr().getText()).append(";\n");
    }

    @Override
    public void enterIncrementStatement(LenguajexParser.IncrementStatementContext ctx) {
        String varName = ctx.ID().getText();
        if (!symbolTable.containsKey(varName)) {
            undeclaredVariables.add(varName);
        }
        code.append(varName).append("++;\n");
    }

    @Override
    public void enterDecrementStatement(LenguajexParser.DecrementStatementContext ctx) {
        String varName = ctx.ID().getText();
        if (!symbolTable.containsKey(varName)) {
            undeclaredVariables.add(varName);
        }
        code.append(varName).append("--;\n");
    }

    @Override
    public void enterWhileLoop(LenguajexParser.WhileLoopContext ctx) {
        code.append("while (").append(ctx.expr().getText()).append(") {\n");
    }

    @Override
    public void exitWhileLoop(LenguajexParser.WhileLoopContext ctx) {
        code.append("}\n");
    }

    @Override
    public void enterIfStatement(LenguajexParser.IfStatementContext ctx) {
        code.append("if (").append(ctx.expr().getText()).append(") {\n");
    }

    @Override
    public void exitIfStatement(LenguajexParser.IfStatementContext ctx) {
        code.append("}\n");
    }

    @Override
    public void enterElseBlock(LenguajexParser.ElseBlockContext ctx) {
        code.append("else {\n");
    }

    @Override
    public void exitElseBlock(LenguajexParser.ElseBlockContext ctx) {
        code.append("}\n");
    }

    @Override
    public void enterFunctionCall(LenguajexParser.FunctionCallContext ctx) {
        String funcName = ctx.ID().getText();
        if (!definedFunctions.contains(funcName)) {
            System.err.println("\tError Semántico: La función '" + funcName + "' no está definida.");
            hasSemanticError = true;
        }
        String arguments = ctx.exprList() != null ? ctx.exprList().getText() : "";
        code.append(funcName).append("(").append(arguments).append(");\n");
    }

    @Override
    public void enterReturnStatement(LenguajexParser.ReturnStatementContext ctx) {
        code.append("return ").append(ctx.expr().getText()).append(";\n");
    }

    @Override
    public void enterShowStatement(LenguajexParser.ShowStatementContext ctx) {
        String expr = ctx.expr().getText();
        code.append("console.log(").append(expr).append(");\n");
    }

    @Override
    public void enterExpr(LenguajexParser.ExprContext ctx) {
        //
    }

    @Override
    public void exitExpr(LenguajexParser.ExprContext ctx) {
        //
    }

    @Override
    public void enterEveryRule(ParserRuleContext ctx) {
        super.enterEveryRule(ctx);
    }

    @Override
    public void exitEveryRule(ParserRuleContext ctx) {
        super.exitEveryRule(ctx);
    }

    @Override
    public void visitTerminal(TerminalNode node) {
        super.visitTerminal(node);
    }

    @Override
    public void visitErrorNode(ErrorNode node) {
        super.visitErrorNode(node);
    }

    public static String getGeneratedCode() {
        return code.toString();
    }

    private String formatParameters(LenguajexParser.ParameterListContext ctx) {
        StringBuilder formattedParams = new StringBuilder();
        for (int i = 0; i < ctx.parameter().size(); i++) {
            LenguajexParser.ParameterContext param = ctx.parameter(i);
            formattedParams.append(param.getText().replace("int", "int ").replace("string", "string "));
            if (i < ctx.parameter().size() - 1) {
                formattedParams.append(", ");
            }
        }
        return formattedParams.toString();
    }

    public boolean hasSemanticErrors() {
        return hasSemanticError;
    }
}
