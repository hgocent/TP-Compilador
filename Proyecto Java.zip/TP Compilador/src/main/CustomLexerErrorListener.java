import org.antlr.v4.runtime.*;

public class CustomLexerErrorListener extends BaseErrorListener {
    public static boolean hasLexicError = false;

    @Override
    public void syntaxError(Recognizer<?, ?> recognizer, Object offendingSymbol,
                            int line, int charPositionInLine, String msg, RecognitionException e) {
        System.err.println("Error de reconocimiento de token en la línea " + line + ", posición " + charPositionInLine + ": " + msg);
        hasLexicError = true;
    }

    public static boolean hasLexicError() {
        return hasLexicError;
    }
}

