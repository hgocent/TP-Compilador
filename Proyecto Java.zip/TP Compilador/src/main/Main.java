import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

import org.antlr.v4.gui.TreeViewer;

import java.awt.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;

import javax.swing.*;
import java.util.Arrays;
import java.util.concurrent.CountDownLatch;

public class Main {
    // Defino un CountDownLatch para controlar el flujo del CustomListener. Para que no continúe el flujo si aún no ha terminado de ejecutarse el walker.
    public static CountDownLatch latch = new CountDownLatch(1);

    public static void main(String[] args) throws Exception {
        String response = "y";
        synchronized (System.out) {
            System.out.println("Compilador de LenguajeX");
            System.out.println("⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻");
            System.out.println("Inicio de análisis sintáctico...");
        }

        // Leer el código fuente a compilar (elegir variantes de prueba)
         CharStream input = CharStreams.fromFileName("CodigoFuenteOriginal.input"); // Código original, sin errores sintacticos pero con errores semánticos de variables no declaradas
        // CharStream input = CharStreams.fromFileName("CodigoFuenteSinErrores.input"); // Código sin errores
        // CharStream input = CharStreams.fromFileName("CodigoFuenteConErrores.input"); // Código de prueba con errores sintácticos

        // Crear el lexer (tokenizador o scanner)
        LenguajexLexer lexer = new LenguajexLexer(input);
        lexer.removeErrorListeners(); // Elimina el listener de error por defecto
        lexer.addErrorListener(new CustomLexerErrorListener()); // Reemplaza el manejador de errores por defecto. Agrega el listener de errores personalizados relacionados al análisis léxicográfico
        CommonTokenStream tokens = new CommonTokenStream(lexer); // Crear el buffer de tokens para guardarlos

        // Crear el parser (analizador sintáctico)
        LenguajexParser parser = new LenguajexParser(tokens);
        parser.removeErrorListeners(); // Elimina el listener de error por defecto
        parser.addErrorListener(new CustomParserErrorListener()); // Reemplaza el manejador de errores por defecto. Agrega el listener de errores personalizados relacionados al análisis sintáctico.

        // Inicia el parser comenzando con la primera regla que es: 'program'.
        ParseTree tree = parser.program(); // Construye un árbol sintáctico en la variable tree.

        if (!CustomParserErrorListener.hasSyntaxError() && !CustomLexerErrorListener.hasLexicError()) {

            // Crear una vista gráfica del árbol y guardarla como imagen utilizando una función personalizada
            saveParseTreeAsImage(parser, tree, "arbol_sintactico.png");
            synchronized (System.out) {
                System.out.println("\tEl código fuente no presenta errores de sintaxis.\n\tVer el árbol en: 'arbol_sintactico.png'");
                System.out.println("Inicio de análisis semántico...");
            }

            // Analizador semántico y generador de código (ya que se manejan en el mismo listener).
            ParseTreeWalker walker = new ParseTreeWalker(); // Crear una instancia para recorrer el árbol sintáctico
            LenguajexCustomListener listener = new LenguajexCustomListener(); // Declarar listener para monitorear los eventos que ocurren mientras se recorre el árbol sintáctico.
            walker.walk(listener, tree); // Recorrer el árbol sintáctico para analizar errores semánticos y generar el código intermedio.

            // Llamar al método await() en el CountDownLatch para esperar hasta que el recuento llegue a cero y asegurar que el walker terminó el recorrido para evitar que los mensajes aparezcan desincronizados en la consola.
            latch.await();

            // Si el listener arroja errores semánticos, preguntar si se debe finalizar o continuar con la última etapa (generación de código)
            if (listener.hasSemanticErrors()) {

                Scanner scanner = new Scanner(System.in);
                synchronized (System.out) { System.out.print("\tExisten errores semánticos. ¿Desea continuar con la compilación de todas formas? [y/n]: "); }
                response = scanner.nextLine();
                scanner.close();

                // Procesar la respuesta del usuario
                if (response.equalsIgnoreCase("n")) {
                    synchronized (System.out) {
                        System.out.println("\nCompilación cancelada por errores semánticos.");
                        System.out.println("\nProceso Finalizado.");
                    }
                    return; // Terminar la compilación
                }
            } else {
                synchronized (System.out) { System.out.println("\tEl código ingresado no presenta errores semánticos."); }
            }

            synchronized (System.out) { System.out.println("Generando el código intermedio..."); }
            // Obtener el código generado
            String generatedCode;
            generatedCode = LenguajexCustomListener.getGeneratedCode();
            // System.out.println("Código generado:\n" + generatedCode);

            // Guardar el código intermedio en un archivo
            try (FileWriter fileWriter = new FileWriter("codigo_intermedio.js")) {
                fileWriter.write(generatedCode);
                synchronized (System.out) { System.out.println("\tCódigo intermedio guardado correctamente.\n\tVer código en: 'codigo_intermedio.js'"); }
            } catch (IOException e) {
                synchronized (System.out) { System.out.println("\tOcurrió un error guardando el archivo: " + e.getMessage()); }
            }

            synchronized (System.out) { System.out.println("\nProceso Finalizado."); }

        } else {
            synchronized (System.out) { System.out.println("\nCompilación fallida. El código ingresado presenta errores de sintaxis."); }
        }
    }

    // Función para guardar el árbol de derivación en una imagen
    private static void saveParseTreeAsImage(LenguajexParser parser, ParseTree tree, String fileName) {
        JFrame frame = new JFrame();
        JPanel panel = new JPanel();
        // Declaro un visor de tipo TreeViewer (Clase que permite dibujar el árbol) pasándole los parámetros necesarios: El array de las reglas y el árbol sintáctico para comprender la jerarquía.
        TreeViewer viewer = new TreeViewer(Arrays.asList(parser.getRuleNames()), tree);

        // Calcular el tamaño preferido del TreeViewer
        Dimension preferredSize = viewer.getPreferredSize();

        // Tamaño máximo del frame
        int maxWidth = 1600;
        int maxHeight = 900;

        // Calcular la escala necesaria para que el TreeViewer quepa en el frame
        double scaleX = (double) maxWidth / (preferredSize.width + 1);
        double scaleY = (double) maxHeight / (preferredSize.height + 1);
        double scale = Math.min(scaleX, scaleY);

        // Aplicar la escala al TreeViewer
        viewer.setScale(scale);

        panel.add(viewer);
        frame.add(panel);
        frame.pack();
        // frame.setSize(maxWidth, maxHeight);

        // Renderizar el panel en una imagen
        BufferedImage image = new BufferedImage(panel.getWidth(), panel.getHeight(), BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = image.createGraphics();
        panel.paint(g2);
        g2.dispose();

        // Guardar la imagen en un archivo
        try {
            ImageIO.write(image, "png", new File(fileName));
        } catch (IOException e) {
            e.printStackTrace();
        }

        frame.dispose();
    }

}
