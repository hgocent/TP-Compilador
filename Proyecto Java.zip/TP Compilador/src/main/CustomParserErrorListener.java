import org.antlr.v4.runtime.*;

public class CustomParserErrorListener extends BaseErrorListener {
    public static boolean hasSyntaxError = false;

    @Override
    public void syntaxError(Recognizer<?, ?> recognizer, Object offendingSymbol,
                            int line, int charPositionInLine, String msg, RecognitionException e) {

        System.err.println("\tError de sintaxis en la línea " + line + ", posición " + charPositionInLine + ": " + msg);
        hasSyntaxError = true;
    }

    public static boolean hasSyntaxError() {

        return hasSyntaxError;
    }

}