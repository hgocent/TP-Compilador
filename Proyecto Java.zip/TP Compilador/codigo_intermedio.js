function calcular(int x, int y=10, string arr) {
z = x**4;
i = 0;
while (i<z-y) {
r = r+arr[i];
i++;
}
return r;
}
function main() {
a = {1,2,8,4,6};
resultado = calcular(4,5,a);
if (resultado>0) {
console.log(resultado);
else {
console.log("error");
}
}
}
main();
